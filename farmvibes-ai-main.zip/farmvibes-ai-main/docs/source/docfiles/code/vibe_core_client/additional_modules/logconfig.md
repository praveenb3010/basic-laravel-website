# Logconfig

```{eval-rst}
.. automodule:: vibe_core.logconfig
   :members:
   :show-inheritance:
```

```{eval-rst}
.. autosummary::
   :toctree: _autosummary
```
