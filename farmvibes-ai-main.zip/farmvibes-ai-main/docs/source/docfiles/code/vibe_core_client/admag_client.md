# Azure Data Manager for Agriculture

```{eval-rst}
.. automodule:: vibe_core.admag_client
   :members:
   :show-inheritance:
```

```{eval-rst}
.. autosummary::
   :toctree: _autosummary
```
