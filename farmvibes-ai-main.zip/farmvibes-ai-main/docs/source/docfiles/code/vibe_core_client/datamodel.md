# Data Model

```{eval-rst}
.. automodule:: vibe_core.datamodel
   :members:
   :show-inheritance:
```

```{eval-rst}
.. autosummary::
   :toctree: _autosummary
```
